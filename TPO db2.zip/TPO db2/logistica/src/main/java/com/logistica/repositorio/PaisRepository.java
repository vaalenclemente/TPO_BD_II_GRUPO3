package com.logistica.repositorio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.logistica.database.MySQLConexion;

import com.logistica.modelo.Pais;

public class PaisRepository {

    private Pais mapear(ResultSet rs) throws SQLException {
        Pais p = new Pais();
        p.setId(rs.getInt("id"));
        p.setNombre(rs.getString("nombre"));
        return p;
    }

    public List<Pais> listar() throws SQLException {
        String sql = """
                SELECT * FROM pais ORDER BY nombre
                """;

        try (Connection c = MySQLConexion.getConexion();
                PreparedStatement ps = c.prepareStatement(sql)) {

            List<Pais> paises = new ArrayList<>();

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next() == true) {
                    paises.add(mapear(rs));
                }
            }
            return paises;
        }
    }

    public Pais buscarPorId(int id) throws SQLException {
        String sql = """
                SELECT * FROM pais WHERE id=?
                """;

        try (Connection c = MySQLConexion.getConexion();
                PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() == true) {
                    return mapear(rs);
                } else {
                    return null;
                }
            }
        }

    }
}
