package com.logistica.servicio;

import java.util.ArrayDeque;
import java.util.Deque;

import com.logistica.repositorio.SagaRepository;

public class Saga {

    public interface Accion {
        void ejecutar() throws Exception;
    }

    private final SagaRepository repo = new SagaRepository();
    private final String id;
    private final Deque<Accion> compensaciones = new ArrayDeque<>();

    public Saga(String tipo) {
        this.id = repo.iniciar(tipo);
    }

    public void objeto(Object objetoId) {
        repo.asignarObjeto(id, objetoId);
    }

    public void paso(String nombre, Accion compensacion) {
        if (compensacion != null) {
            compensaciones.push(compensacion);
        }
        repo.registrarPaso(id, nombre);
    }

    public void completar() {
        repo.completar(id);
    }

    public IllegalStateException fallar(Exception causa) {
        String mensaje = causa.getMessage();

        try {
            while (!compensaciones.isEmpty()) {
                compensaciones.pop().ejecutar();
            }
            repo.compensada(id, mensaje);
        } catch (Exception errorAlDeshacer) {
            try {
                repo.error(id, mensaje + " | al compensar: " + errorAlDeshacer.getMessage());
            } catch (Exception ignorada) {

            }
        }

        return new IllegalStateException("No se pudo completar la operación: " + mensaje, causa);
    }

}
