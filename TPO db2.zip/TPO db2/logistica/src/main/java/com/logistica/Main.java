package com.logistica;

import java.util.Scanner;
import java.sql.Connection;
import java.sql.SQLException;
import com.logistica.database.MySQLConexion;
import com.logistica.database.MySQLInicializacion;

import org.bson.Document;
import com.mongodb.MongoException;
import com.logistica.database.MongoInicializacion;
import com.logistica.database.MongodbConexion;
import org.neo4j.driver.exceptions.Neo4jException;
import com.logistica.database.Neo4jInicializacion;
import com.logistica.database.Neo4jConexion;
import com.logistica.database.Neo4jInicializacion;
import com.logistica.database.RedisConexion;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.exceptions.JedisException;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== SISTEMA LOGISTICO CLI ===");

        try (Connection c = MySQLConexion.getConexion()) {
            System.out.println("Conexión a MySQL exitosa.");
        } catch (SQLException e) {
            System.out.println("Falló la conexión MySQL: " + e.getMessage());
            return;
        }

        try {
            MongodbConexion.getDatabase().runCommand(new Document("ping", 1));
            System.out.println("Conexión a MongoDB exitosa.");
        } catch (MongoException e) {
            System.out.println("Falló la conexión MongoDB: " + e.getMessage());
            return;
        }

        try {
            Neo4jConexion.getDriver().verifyConnectivity();
            System.out.println("Conexión a neo4j exitosa.");
        } catch (Neo4jException e) {
            System.out.println("Falló la conexión neo4j: " + e.getMessage());
            return;
        }

        try (Jedis j = RedisConexion.getConexion()) {
            j.ping();
            System.out.println("Conexión a Redis exitosa.");
        } catch (JedisException e) {
            System.out.println("Falló la conexión Redis: " + e.getMessage());
        }

        try {
            MySQLInicializacion.inicializar();
            System.out.println("Estructura MySQL lista.");
        } catch (SQLException e) {
            System.out.println("Falló la creación de tablas MySQL: " + e.getMessage());
            return;
        }

        try {
            MongoInicializacion.inicializar();
            System.out.println("Estructura Mongo lista.");
        } catch (MongoException e) {
            System.out.println("Falló la creación de índices Mongo: " + e.getMessage());
            return;
        }

        try {
            Neo4jInicializacion.inicializar();
            System.out.println("Estructura Neo4j lista.");
        } catch (Neo4jException e) {
            System.out.println("Falló la creación de índices Neo4j: " + e.getMessage());
            return;
        }

        System.out.print("Nombre del operador: ");
        String usuarioActual = scanner.nextLine().trim();
        System.out.println("Bienvenido, " + usuarioActual + ".");

        boolean salir = false;
        while (!salir) {
            System.out.println();
            System.out.println("0. Salir");
            System.out.print("> ");
            String opcion = scanner.nextLine().trim();

            switch (opcion) {
                case "0" -> salir = true;
                default -> System.out.println("Opción inválida.");
            }
        }

        System.out.println("Hasta luego.");
    }
}