package com.logistica.repositorio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.logistica.database.MySQLConexion;

import com.logistica.modelo.Ciudad;

public class CiudadRepository {

    private Ciudad mapear(ResultSet rs) throws SQLException {
        Ciudad c = new Ciudad();
        c.setId(rs.getInt("id"));
        c.setNombre(rs.getString("nombre"));
        c.setPaisId(rs.getObject("pais_id", Integer.class));
        return c;
    }

    public List<Ciudad> listarPorPais(int paisId) throws SQLException {
        String sql = """
                SELECT * FROM ciudad WHERE pais_id = ? ORDER BY nombre
                """;

        try (Connection c = MySQLConexion.getConexion();
                PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, paisId);
            List<Ciudad> ciudades = new ArrayList<>();

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next() == true) {
                    ciudades.add(mapear(rs));
                }
            }
            return ciudades;
        }
    }

    public Ciudad buscarPorId(int id) throws SQLException {
        String sql = """
                SELECT * FROM ciudad WHERE id = ?
                """;

        try (Connection c = MySQLConexion.getConexion();
                PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() == true) {
                    return mapear(rs);
                } else {
                    return null;
                }
            }
        }

    }

}
