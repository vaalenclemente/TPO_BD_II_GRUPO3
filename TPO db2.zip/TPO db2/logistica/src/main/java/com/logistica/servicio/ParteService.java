package com.logistica.servicio;

import com.logistica.modelo.Parte;
import com.logistica.repositorio.ParteRepository;

import java.sql.SQLException;
import java.time.LocalDateTime;

public class ParteService {

    private final ParteRepository repo = new ParteRepository();

    public int alta(Parte p) throws SQLException {
        // validaciones

        if (!"CLIENTE".equals(p.getTipo()) && !"OPERADOR".equals(p.getTipo()) && !"PROVEEDOR".equals(p.getTipo())) {
            throw new IllegalArgumentException("El tipo no es correcto (CLIENTE, OPERADOR, PROVEEDOR)");
        }

        if (p.getRazonSocial() == null || p.getRazonSocial().isBlank()) {
            throw new IllegalArgumentException("La razón social es obligatoria.");
        }

        if (p.getCuit() == null || p.getCuit().isBlank()) {
            throw new IllegalArgumentException("El CUIT es obligatorio.");
        }

        if (p.getEmail() == null || p.getEmail().isBlank()) {
            throw new IllegalArgumentException("El Mail es obligatorio.");
        }

        if (p.getPaisId() == null) {
            throw new IllegalArgumentException("El Pais de origen es obligatorio.");
        }

        if (p.getRubro() != null && !"PROVEEDOR".equals(p.getTipo())) {
            throw new IllegalArgumentException("Solo los proveedores pueden tener rubro.");
        }

        if (repo.buscarPorCuit(p.getCuit()) != null) {
            throw new IllegalArgumentException("El CUIT ya existe en la base de datos.");
        }

        // valores del sistema

        p.setFechaAlta(LocalDateTime.now());
        p.setEstado("ACTIVO");

        // guardar

        int id = repo.guardar(p);
        p.setId(id);
        return id;
    }
}