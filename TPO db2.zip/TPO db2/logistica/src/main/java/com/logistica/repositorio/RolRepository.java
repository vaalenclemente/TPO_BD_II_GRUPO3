package com.logistica.repositorio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.logistica.database.MySQLConexion;

import com.logistica.modelo.Rol;

public class RolRepository {

    private Rol mapear(ResultSet rs) throws SQLException {
        Rol r = new Rol();
        r.setId(rs.getInt("id"));
        r.setDescripcion(rs.getString("descripcion"));
        r.setNivelPermisos(rs.getObject("nivel_permisos", Integer.class));
        return r;
    }

    public List<Rol> listar() throws SQLException {
        String sql = """
                SELECT * FROM rol ORDER BY descripcion
                """;

        try (Connection c = MySQLConexion.getConexion();
                PreparedStatement ps = c.prepareStatement(sql)) {

            List<Rol> roles = new ArrayList<>();

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    roles.add(mapear(rs));
                }
            }
            return roles;
        }
    }

    public Rol buscarPorId(int id) throws SQLException {
        String sql = """
                SELECT * FROM rol WHERE id = ?
                """;

        try (Connection c = MySQLConexion.getConexion();
                PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                } else {
                    return null;
                }
            }
        }
    }

}
